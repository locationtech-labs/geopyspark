from distutils.core import setup

setup(
    name='SpatialKey',
    version='0.1',
    packages=['.',],
    license='Apache 2.0',
)
